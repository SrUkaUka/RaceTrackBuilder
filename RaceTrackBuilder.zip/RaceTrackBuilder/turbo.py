import bpy
import json
import os
from collections import OrderedDict
import bpy_extras.io_utils  # ✅ Importamos ExportHelper

class MyProperties(bpy.types.PropertyGroup):
    def update_none(self, context):
        if self.none:
            self.turbo_pad = False
            self.super_turbo_pad = False

    def update_turbo_pad(self, context):
        if self.turbo_pad:
            self.none = False
            self.super_turbo_pad = False

    def update_super_turbo_pad(self, context):
        if self.super_turbo_pad:
            self.none = False
            self.turbo_pad = False

    none: bpy.props.BoolProperty(name="None", default=True, update=update_none)
    turbo_pad: bpy.props.BoolProperty(name="Turbo Pad", default=False, update=update_turbo_pad)
    super_turbo_pad: bpy.props.BoolProperty(name="Super Turbo Pad", default=False, update=update_super_turbo_pad)


class OBJECT_PT_turbo_panel(bpy.types.Panel):
    bl_label = "Turbo Settings"
    bl_idname = "OBJECT_PT_turbo_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    def draw(self, context):
        layout = self.layout
        obj = context.object

        if obj and obj.my_props:
            props = obj.my_props
            layout.prop(props, "none", toggle=True, text="None")
            layout.prop(props, "turbo_pad", toggle=True, text="Turbo Pad")
            layout.prop(props, "super_turbo_pad", toggle=True, text="Super Turbo Pad")

        layout.operator("export.turbo_preset", text="Export Preset", icon="EXPORT")


class EXPORT_OT_turbo_preset(bpy.types.Operator, bpy_extras.io_utils.ExportHelper):  # ✅ Se usa ExportHelper
    """Exporta la configuración de turbo a un archivo JSON"""
    bl_idname = "export.turbo_preset"
    bl_label = "Export Turbo Preset"
    
    filename_ext = ".json"  # ✅ Forzar la extensión .json
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    defaultextension = ".json"  # ✅ Se asegura de que Blender no borre la extensión

    def execute(self, context):
        turbo_data = OrderedDict()
        turbopads_list = []

        for obj in bpy.data.objects:
            if hasattr(obj, "my_props") and obj.my_props:
                props = obj.my_props
                if props.super_turbo_pad:
                    turbo_data[f"{obj.name}_trigger"] = 2
                    turbopads_list.append(obj.name)
                elif props.turbo_pad:
                    turbo_data[f"{obj.name}_trigger"] = 1
                    turbopads_list.append(obj.name)

        turbo_data["header"] = 4
        turbo_data["turbopads"] = turbopads_list

        try:
            with open(self.filepath, "w") as f:
                json.dump(turbo_data, f, indent=4)
            self.report({'INFO'}, f"Preset exportado en {self.filepath}")
        except Exception as e:
            self.report({'ERROR'}, f"Error al guardar: {e}")

        return {'FINISHED'}

    def invoke(self, context, event):
        self.filepath = bpy.path.abspath("//untitled.json")  # ✅ Sugiere "untitled.json"
        context.window_manager.fileselect_add(self)  # ✅ Abre el explorador de archivos con la sugerencia
        return {'RUNNING_MODAL'}


def register():
    try:
        unregister()
    except Exception:
        pass

    bpy.utils.register_class(MyProperties)
    bpy.utils.register_class(OBJECT_PT_turbo_panel)
    bpy.utils.register_class(EXPORT_OT_turbo_preset)
    bpy.types.Object.my_props = bpy.props.PointerProperty(type=MyProperties)


def unregister():
    bpy.utils.unregister_class(MyProperties)
    bpy.utils.unregister_class(OBJECT_PT_turbo_panel)
    bpy.utils.unregister_class(EXPORT_OT_turbo_preset)
    del bpy.types.Object.my_props


if __name__ == "__main__":
    register()
